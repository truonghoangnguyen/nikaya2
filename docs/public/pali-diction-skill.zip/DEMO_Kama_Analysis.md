# 🔍 DEMO: Phân tích từ "Kāma" (Dục)

> Đây là ví dụ minh họa output của **pali-dictionary skill** khi phân tích từ Pali "Kāma"

---

# KĀMA (กาม)

## 1. Thông tin cơ bản

- **Từ gốc:** Kāma (กาม)
- **Dịch của HT Thích Minh Châu:** "Dục"
- **Từ loại:** Danh từ

## 2. Từ ghép và biến thể

### 2.1 Từ ghép chính

- **Kāma-taṇhā** (dục ái)
  - Dịch TMC: "Dục ái"
  - Nghĩa: Khát ái đối với đối tượng giác quan
  
- **Kāma-rāga** (dục nhiễm)
  - Dịch TMC: "Dục tham"
  - Nghĩa: Đam mê đối với đối tượng giác quan

- **Kāma-guṇa** (dục trần)
  - Dịch TMC: "Dục trần"
  - Nghĩa: Các đối tượng làm thỏa mãn giác quan (sắc, thanh, hương, vị, xúc)

- **Kāma-loka** (dục giới)
  - Dịch TMC: "Dục giới"
  - Nghĩa: Cõi của các chúng sinh bị chi phối bởi dục

- **Kāma-chanda** (dục tham)
  - Dịch TMC: "Dục tham"
  - Nghĩa: Tham muốn đối tượng giác quan (một trong Ngũ Cái)

- **Kāma-vitakka** (dục tầm)
  - Dịch TMC: "Dục tầm"
  - Nghĩa: Tư duy hướng về đối tượng giác quan

### 2.2 Từ đồng nghĩa/liên quan

- **Taṇhā** (ái) - Khát ái, khao khát
- **Rāga** (tham) - Đam mê, tham đắm
- **Lobha** (tham) - Lòng tham
- **Chanda** (dục) - Ham muốn

## 3. Ngữ cảnh trong kinh điển

### 3.1 Trong Tứ Thánh Đế (Tập Đế)

**Trích dẫn:**
> **Pali:** Katamā ca, bhikkhave, dukkha-samudayo ariya-saccaṃ? Yāyaṃ taṇhā ponobbhavikā nandi-rāga-sahagatā tatra-tatrābhinandinī, seyyathīdaṃ: **kāma-taṇhā**, bhava-taṇhā, vibhava-taṇhā.
> 
> **Dịch TMC:** Này các Tỷ-kheo, thế nào là Khổ Tập Thánh đế? Chính là ái này đưa đến tái sanh, câu hữu với hỷ và tham, tìm cầu hỷ lạc chỗ này chỗ kia. Tức là: **dục ái**, hữu ái, phi hữu ái.

**Phân tích ngữ cảnh:**

Ở đây "kāma-taṇhā" được dùng song song với "bhava-taṇhā" (hữu ái) và "vibhava-taṇhā" (phi hữu ái). 

🔍 **Phát hiện quan trọng:** Nếu hiểu "kāma" là "ham muốn" thì "kāma-taṇhā" sẽ thành "ham muốn khát ái" - **THỪA NGHĨA!** ❌

Do đó "kāma" ở đây nên hiểu là **"đối tượng giác quan"**, không phải chính "ham muốn".

### 3.2 Trong Thập Phiền Não (Dasa Saṃyojanāni)

**Trích dẫn:**
> **Pali:** Kāma-rāgo saṃyojanaṃ
> 
> **Dịch TMC:** Dục tham là kiết sử

**Phân tích ngữ cảnh:**

"Kāma-rāga" là một trong Thập Phiền Não (mười kiết sử). "Rāga" nghĩa là "tham đắm, say mê".

🔍 **Phân tích:** Nếu "kāma" = "ham muốn" thì "kāma-rāga" = "ham muốn say mê" - lại **THỪA NGHĨA!** ❌

"Rāga" là **tâm sở** (trạng thái tâm), còn "kāma" phải là **đối tượng** bị say mê.

### 3.3 Trong Ngũ Dục Công Đức (Kāma-guṇa)

**Trích dẫn:**
> **Pali:** Pañca kāma-guṇā: rūpā, saddā, gandhā, rasā, phoṭṭhabbā
> 
> **Dịch TMC:** Năm dục trần: sắc, thanh, hương, vị, xúc

**Phân tích ngữ cảnh:**

Đây là định nghĩa rõ ràng nhất: "Kāma-guṇa" = 5 đối tượng giác quan cụ thể (sắc, thanh, hương, vị, xúc).

🔍 **Kết luận quyết định:** "Kāma" chính là **CÁC ĐỐI TƯỢNG** này, không phải ham muốn chúng!

## 4. Biện luận Logic ⭐

### 4.1 Kiểm tra từ ghép

**Giả thuyết A:** Kāma = "ham muốn/dục vọng"

- Kāma-taṇhā = "ham muốn + khát ái" → **"Ham muốn khát ái"** (THỪA! ❌)
- Kāma-rāga = "ham muốn + đam mê" → **"Ham muốn đam mê"** (THỪA! ❌)
- Kāma-guṇa = "ham muốn + phẩm chất" → **"Phẩm chất ham muốn"** (MÂU THUẪN! ❌)
  - Vì kāma-guṇa được định nghĩa là 5 đối tượng cụ thể (sắc, thanh...), không phải "ham muốn"

**Giả thuyết B:** Kāma = "đối tượng giác quan/dục trần"

- Kāma-taṇhā = "đối tượng giác quan + khát ái" → **"Khát ái đối tượng giác quan"** (NHẤT QUÁN! ✓)
- Kāma-rāga = "đối tượng giác quan + đam mê" → **"Đam mê đối tượng giác quan"** (NHẤT QUÁN! ✓)
- Kāma-guṇa = "đối tượng giác quan + phẩm chất" → **"Phẩm chất/thuộc tính giác quan"** (NHẤT QUÁN! ✓)
- Kāma-loka = "đối tượng giác quan + cõi" → **"Cõi chi phối bởi giác quan"** (NHẤT QUÁN! ✓)

### 4.2 Ma trận tương thích

```
┌────────────────┬──────────────────┬──────────────────┬────────────┐
│ Từ ghép        │ Nghĩa A          │ Nghĩa B          │ Tốt nhất   │
│                │ (Ham muốn)       │ (Đối tượng)      │            │
├────────────────┼──────────────────┼──────────────────┼────────────┤
│ Kāma-taṇhā    │ Thừa nghĩa ❌    │ Nhất quán ✓      │ B          │
│ Kāma-rāga     │ Thừa nghĩa ❌    │ Nhất quán ✓      │ B          │
│ Kāma-guṇa     │ Mâu thuẫn ❌     │ Nhất quán ✓      │ B          │
│ Kāma-loka     │ Chấp nhận được   │ Tốt hơn ✓        │ B          │
│ Kāma-chanda   │ Thừa nghĩa ❌    │ Nhất quán ✓      │ B          │
│ Kāma-vitakka  │ Thừa nghĩa ❌    │ Nhất quán ✓      │ B          │
└────────────────┴──────────────────┴──────────────────┴────────────┘
```

### 4.3 Kết luận logic

**Giả thuyết B (Kāma = "đối tượng giác quan") nhất quán trong TẤT CẢ các từ ghép**, trong khi Giả thuyết A gây thừa nghĩa hoặc mâu thuẫn.

**Bằng chứng quyết định:**
1. Kāma-guṇa được định nghĩa rõ ràng = 5 đối tượng (sắc, thanh, hương, vị, xúc)
2. Các từ ghép với taṇhā, rāga, chanda (đều là tâm sở) → kāma phải là đối tượng
3. Nguyên tắc đối xứng: Nếu có "bhava-taṇhā" (khát ái hữu), "vibhava-taṇhā" (khát ái phi hữu), thì "kāma-taṇhā" phải là "khát ái + đối tượng"

## 5. Đề xuất dịch thuật

### 5.1 Sát nghĩa đen (cho chú giải)

- **Kāma** → **"Dục trần"** hoặc **"Đối tượng giác quan"**
- **Lý do:** Sát với nghĩa Pali, phân biệt rõ với các từ như:
  - Taṇhā (khát ái) - tâm sở
  - Rāga (tham đắm) - tâm sở  
  - Chanda (ham muốn) - tâm sở

### 5.2 Tiếng Việt hiện đại (cho đọc hiểu)

- **Kāma** → **"Khoái lạc giác quan"** hoặc **"Đối tượng dục"**
- **Lý do:** 
  - Dễ hiểu cho người đọc hiện đại
  - Tránh nhầm lẫn với "ham muốn" (desire)
  - Nhấn mạnh tính chất "đối tượng bên ngoài"
- **Ví dụ:** 
  - Kāma-guṇa → "Năm loại khoái lạc giác quan" 
  - Kāma-taṇhā → "Khát khao khoái lạc giác quan"

### 5.3 Lưu ý ngữ cảnh

| Ngữ cảnh        | Nên dịch                     | Không nên dịch     | Lý do                                          |
|-----------------|------------------------------|--------------------|------------------------------------------------|
| Tứ Thánh Đế    | "Dục trần"                   | "Ham muốn"         | Tránh thừa với "ái" (taṇhā)                    |
| Thập Phiền Não | "Đối tượng giác quan"        | "Dục vọng"         | Phân biệt đối tượng (kāma) và tâm sở (rāga)    |
| Tam Giới       | "Dục giới"                   | "Giới ham muốn"    | Thuật ngữ quen thuộc, đã ổn định               |
| Kāma-guṇa      | "Năm dục trần" / "Ngũ dục"   | "Năm ham muốn"     | Chỉ 5 đối tượng cụ thể (sắc, thanh, hương...) |
| Kāma-loka      | "Dục giới" / "Cõi dục"       | "Cõi ham muốn"     | Thuật ngữ chuẩn trong Phật học                 |
| Đại chúng      | "Khoái lạc giác quan"        | "Dục"              | Dễ hiểu hơn, tránh Hán-Việt khó hiểu           |

## 6. Tóm tắt và khuyến nghị

### Hiểu đúng nhất

**"Kāma" trong tiếng Pali không phải là trạng thái tâm lý "ham muốn", mà là CÁC ĐỐI TƯỢNG BÊN NGOÀI kích thích các giác quan** (sắc, thanh, hương, vị, xúc). 

**Phân biệt rõ:**
- **Kāma** (กาม) = Đối tượng dục, dục trần → **ĐỐI TƯỢNG**
- **Taṇhā** (ตัณหา) = Khát ái → **TÂM SỞ**
- **Rāga** (ราคะ) = Tham đắm → **TÂM SỞ**
- **Chanda** (ฉันทะ) = Ham muốn → **TÂM SỞ**

### Khuyến nghị dịch

#### ✅ Nên dùng:

**Văn cảnh học thuật:**
- "Dục trần" (khi muốn sát nghĩa Hán-Việt)
- "Đối tượng giác quan" (khi muốn rõ nghĩa)

**Văn cảnh đại chúng:**
- "Khoái lạc giác quan"
- "Đối tượng dục"

#### ❌ Nên tránh:

- **"Ham muốn"** - Vì đây là nghĩa của taṇhā, chanda, không phải kāma
- **"Dục vọng"** - Gây nhầm lẫn giữa đối tượng và tâm sở
- **Chỉ dịch "Dục"** (nếu không có chú thích) - Người đọc hiện đại dễ hiểu nhầm

### Ví dụ áp dụng

**Câu kinh:** "Kāma-taṇhā dukkhassa mūlaṃ"

❌ **Dịch sai:** "Ham muốn khát ái là gốc khổ"  
→ Thừa nghĩa! "Ham muốn" và "khát ái" là một!

✅ **Dịch đúng:** "Khát ái đối với dục trần là gốc khổ"  
→ Rõ ràng: Đối tượng (dục trần) ≠ Tâm sở (khát ái)

---

## 📊 Tóm tắt bằng sơ đồ

```
KĀMA (กาม)
    │
    ├─── KHÔNG PHẢI ❌
    │    ├─ Ham muốn (chanda)
    │    ├─ Khát ái (taṇhā)  
    │    └─ Tham đắm (rāga)
    │
    └─── MÀ LÀ ✓
         ├─ Đối tượng giác quan
         ├─ Dục trần (5 loại)
         │  ├─ Sắc (rūpa)
         │  ├─ Thanh (sadda)
         │  ├─ Hương (gandha)
         │  ├─ Vị (rasa)
         │  └─ Xúc (phoṭṭhabba)
         └─ Khoái lạc giác quan
```

---

**🎯 Kết luận:** Phương pháp "Thế và Thử" giúp chúng ta phát hiện rằng "Kāma" trong Pali là **đối tượng**, không phải **ham muốn**. Đây là phân biệt cực kỳ quan trọng để hiểu đúng giáo lý Phật!

---

> **Lưu ý:** Đây là demo output của skill. Khi sử dụng thực tế, bạn có thể yêu cầu phân tích sâu hơn, thêm trích dẫn, hoặc so sánh với các bản dịch khác.

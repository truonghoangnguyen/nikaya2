# 📚 Pali Dictionary Skill - Hướng Dẫn Sử Dụng

## 🎯 Mục đích

Skill **pali-dictionary** được thiết kế để phân tích sâu từ vựng Pali trong kinh điển nguyên thủy, đặc biệt hữu ích cho:

- ✅ Người nghiên cứu Phật học
- ✅ Dịch giả kinh điển
- ✅ Người muốn hiểu đúng nghĩa gốc của từ Pali
- ✅ Người tìm cách dịch hiện đại cho từ cổ

## 🧠 Phương pháp Einstein được áp dụng

Skill này được thiết kế dựa trên phương pháp tư duy của Einstein:

1. **Nguyên lý cơ bản:** Ngữ nghĩa phụ thuộc ngữ cảnh
2. **Đặt câu hỏi:** Từ ghép tiết lộ nghĩa thật của từ gốc
3. **Thí nghiệm tư duy:** Phương pháp "Thế và Thử" (Plug and Play)
4. **Tìm sự đơn giản:** Hệ thống hóa quy trình phân tích

## 🔑 Tính năng chính

### 1. Phân tích từ ghép (Compound Analysis)
- Liệt kê TẤT CẢ từ ghép chứa từ đang nghiên cứu
- Ví dụ: Kāma → Kāma-taṇhā, Kāma-rāga, Kāma-guṇa, Kāma-loka...

### 2. Biện luận Logic "Thế và Thử" ⭐
- **Kiểm tra thừa thãi:** A+B có tạo "ham muốn ham muốn" không?
- **Kiểm tra mâu thuẫn:** A+B có hợp lý logic không?
- **Ma trận tương thích:** So sánh các giả thuyết nghĩa

### 3. Trích dẫn ngữ cảnh
- Tìm từ trong các nhóm chi pháp: 37 phẩm trợ đạo, Ngũ uẩn, 12 nhân duyên...
- Trích dẫn bản Pali + Bản dịch HT Thích Minh Châu
- Phân tích sắc thái nghĩa trong từng ngữ cảnh

### 4. Đề xuất dịch thuật
- **Sát nghĩa đen:** Cho chú giải học thuật
- **Tiếng Việt hiện đại:** Cho đại chúng đọc hiểu
- **Lưu ý ngữ cảnh:** Khi nào dùng từ nào

## 📖 Cách sử dụng

### Cài đặt
1. Tải file `pali-dictionary.skill`
2. Vào Claude.ai → Settings → Skills
3. Upload file .skill
4. Enable skill

### Ví dụ câu lệnh

```
Giải nghĩa từ "dục" (Kāma) trong kinh
```

```
Phân tích từ "Vedanā" (thọ) và đề xuất cách dịch hiện đại
```

```
So sánh nghĩa của "Dhamma" trong các ngữ cảnh khác nhau
```

```
Tại sao "Kāma-taṇhā" không nên dịch là "ham muốn khát ái"?
```

## 📁 Cấu trúc Skill

```
pali-dictionary/
├── SKILL.md (Hướng dẫn chính)
└── references/
    ├── dhamma-groups.md      (37 phẩm trợ đạo, Ngũ uẩn, 12 nhân duyên...)
    ├── logical-analysis.md   (Phương pháp "Thế và Thử")
    └── output-template.md    (Mẫu output + Ví dụ hoàn chỉnh về "Kāma")
```

## 🎓 Ví dụ Output

Khi bạn hỏi về một từ, skill sẽ trả về phân tích theo 6 phần:

1. **Thông tin cơ bản** - Từ gốc, cách dịch của HT Thích Minh Châu
2. **Từ ghép và biến thể** - Danh sách đầy đủ các từ ghép
3. **Ngữ cảnh trong kinh điển** - Trích dẫn từ các nhóm chi pháp
4. **Biện luận Logic** ⭐ - Phương pháp "Thế và Thử", ma trận tương thích
5. **Đề xuất dịch thuật** - Sát nghĩa + Hiện đại + Lưu ý ngữ cảnh
6. **Tóm tắt và khuyến nghị** - Kết luận cuối cùng

Xem ví dụ chi tiết về phân tích từ "Kāma" trong file `output-template.md`!

## 💡 Nguyên tắc thiết kế

### 1. Logic hơn truyền thống
Nếu cách dịch truyền thống gây thừa nghĩa hoặc mâu thuẫn, skill sẽ:
- Chỉ ra vấn đề một cách tôn trọng
- Đề xuất giải pháp dựa trên logic
- Giải thích rõ ràng lý do

### 2. Từ ghép là chìa khóa
- Nếu A+B thừa nghĩa → A hoặc B bị hiểu sai
- Nếu A+B mâu thuẫn → Cần xem xét lại nghĩa  
- Nếu A+B nhất quán → Nghĩa đúng!

### 3. Ngữ cảnh quyết định sắc thái
Cùng một từ trong Ngũ uẩn vs. 12 nhân duyên có thể có sắc thái khác nhau.

### 4. Tiếng Việt hiện đại
Mục tiêu là giúp người đọc hiện đại hiểu đúng:
- Tránh Hán-Việt khó hiểu
- Dùng từ ngữ đời thường
- Nhưng không làm mất độ chính xác

## 🚀 Mở rộng trong tương lai

- [ ] Thêm từ điển Sanskrit
- [ ] Tích hợp thêm các bản dịch khác (Bhikkhu Bodhi, Nanamoli...)
- [ ] Hỗ trợ phân tích từ Hán-Việt
- [ ] Database các trích dẫn kinh điển đầy đủ hơn

## 📝 Góp ý & Cải thiện

Skill này là công cụ hỗ trợ nghiên cứu. Nếu bạn phát hiện lỗi hoặc có đề xuất cải thiện, vui lòng:

1. Test skill với các từ khác nhau
2. Ghi nhận các trường hợp đặc biệt
3. Đề xuất cải thiện quy trình phân tích
4. Chia sẻ các trích dẫn kinh điển bổ sung

## 📄 License

MIT License - Tự do sử dụng, sửa đổi, và chia sẻ

---

**Được thiết kế với phương pháp tư duy Einstein** 🧠✨

*"Nếu bạn không thể giải thích đơn giản, nghĩa là bạn chưa hiểu đủ rõ." - Albert Einstein*
